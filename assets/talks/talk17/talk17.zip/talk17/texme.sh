#!/bin/bash

file=talk17

# Initial clean up
rm -f *~
rm -f ${file}.toc
rm -f ${file}.aux 
rm -f ${file}.lof
rm -f ${file}.log
rm -f ${file}.blg
rm -f ${file}.dvi
rm -f ${file}.ps
rm -f ${file}.pdf
rm -f ${file}.bbl
rm -f ${file}.out
rm -f ${file}.snm
rm -f ${file}.nav

# TeX up the document
latex ${file} && dvips -Ppdf -G0 -o ${file}.ps ${file}.dvi && osascript distiller.applescript ${file}.ps ${ADPATH}${ADFILE}

# Final clean up
rm -f ${file}.toc
rm -f ${file}.aux 
rm -f ${file}.lof
rm -f ${file}.log
rm -f ${file}.blg
rm -f ${file}.bbl
rm -f ${file}.snm
rm -f ${file}.out
rm -f ${file}.nav
rm -f ${file}.vrb
rm -f ${file}.dvi
rm -f ${file}.ps

